from django.apps import AppConfig


class CbvfinalappConfig(AppConfig):
    name = 'cbvfinalapp'
